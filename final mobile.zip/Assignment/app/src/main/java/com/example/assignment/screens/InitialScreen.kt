package com.example.assignment.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.assignment.Login
import com.example.assignment.R
import com.example.assignment.SignUp
import com.example.assignment.components.ButtonComponent
import com.example.assignment.ui.theme.AssignmentTheme

@Composable
fun InitialScreen(modifier: Modifier = Modifier, navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painter = painterResource(id = R.drawable.logo), contentDescription = null)
        Spacer(Modifier.height(24.dp))
        Text(text= stringResource(R.string.semenggoh_nature_reserve))
        Spacer(modifier = modifier.height(16.dp))
        Text(text="Welcome back")
        Spacer(modifier = modifier.height(40.dp))

        ButtonComponent("Login") {
            navController.navigate(Login)
        }
        Spacer(modifier = modifier.height(24.dp))
        ButtonComponent("Sign Up") {
            navController.navigate(SignUp)
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun InitialScreenPreview() {
    AssignmentTheme {
//        InitialScreen()
    }
}
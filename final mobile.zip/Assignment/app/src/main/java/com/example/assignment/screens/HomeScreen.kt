package com.example.assignment.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.carousel.HorizontalMultiBrowseCarousel
import androidx.compose.material3.carousel.rememberCarouselState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.assignment.Alerts
import com.example.assignment.R
import com.example.assignment.Sighting
import com.example.assignment.Social
import com.example.assignment.TouristInfo
import com.example.assignment.WildlifeMonitoring
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.ui.theme.AssignmentTheme

@Composable
fun HomeScreen(modifier: Modifier = Modifier, innerPadding: PaddingValues, navController: NavController) {
    Column(
        modifier = Modifier.padding(innerPadding)
    ) {
        Row(modifier = Modifier
                .padding(top = 8.dp)
        ) {
            Spacer(modifier = Modifier
                .width(18.dp)
                .weight(0.2f)
            )
            HeadingTextComponent("Welcome to Semenggoh Nature Reserve")
            Spacer(
                modifier = Modifier
                    .width(18.dp)
                    .weight(0.2f)
            )
        }
        Text(
            text= "Photo Gallery",
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 16.dp),
            fontSize = 18.sp
        )
        PhotoCarousel()
        Text(
            text= "Provided Services",
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
            fontSize = 18.sp
        )
        LazyColumn {
            item {
                ActivitiesCard("Tourist Information", "Essential Information") {
                    navController.navigate(TouristInfo)
                }
            }
            item {
                ActivitiesCard("Wildlife Monitoring", "Explore wildlife") {
                    navController.navigate(WildlifeMonitoring)
                }
            }
            item {
                ActivitiesCard("Sighting Map", "View sightings") {
                    navController.navigate(Sighting)
                }
            }
            item {
                ActivitiesCard("Alerts", "Essential Alerts") {
                    navController.navigate(Alerts)
                }
            }
        }

    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PhotoCarousel() {
    val carouselState = rememberCarouselState { 5 }

    HorizontalMultiBrowseCarousel(
        state = carouselState,
        preferredItemWidth = 200.dp,
        maxSmallItemWidth = 180.dp,
        itemSpacing = 16.dp,
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp)
    ) {page ->
        Row(
            modifier = Modifier
                .size(200.dp)
        ) {
            Image(
                painter = painterResource(
                    id = when(page) {
                        0 -> R.drawable.picture1
                        1 -> R.drawable.picture2
                        2 -> R.drawable.picture3
                        3 -> R.drawable.picture4
                        else -> R.drawable.picture5
                    }
                ),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .maskClip(shape = MaterialTheme.shapes.extraLarge)
            )
        }
    }
}

@Composable
private fun ActivitiesCard(
    bigTextValue: String,
    smallTextValue: String,
    onButtonClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .padding(16.dp, 8.dp),
    ) {
        Row(
            modifier = Modifier
                .padding(start = 16.dp, end = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 8.dp)
            ) {
                Text(
                    text = bigTextValue,
                    fontSize = 16.sp
                )
                Text(
                    text = smallTextValue,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
            OutlinedButton(
                onClick = onButtonClick,
                modifier = Modifier
                    .weight(0.6f)
                    .padding(top = 8.dp, bottom = 8.dp)
            ) {
                Text(
                    text = "Show more",
                    color = Color.Black
                )
            }
        }
    }
}
package com.example.assignment.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.breens.beetablescompose.BeeTablesCompose
import com.example.assignment.Account
import com.example.assignment.Donation
import com.example.assignment.components.HeadingTextComponent
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.util.Date

@Composable
fun DonationManagementScreen(innerPadding: PaddingValues) {
    Column(modifier = Modifier
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
    ) {
        HeadingTextComponent("Donation Records")
        val tableHeaders = listOf("Donor Name", "Email", "Phone", "Campaign", "Amount", "Status", "Created At")
        var donations by remember { mutableStateOf<List<Donation>>(emptyList()) }

        LaunchedEffect(Unit) {
            fetchDonations { result ->
                // Update the users state once data is fetched
                donations = result
            }
        }

        BeeTablesCompose(
            data = donations,
            headerTableTitles = tableHeaders,
            dividerThickness = 0.8.dp,
        )
    }
}

private fun fetchDonations(callback: (List<Donation>) -> Unit) {
    val firestore = FirebaseFirestore.getInstance()

    firestore.collection("donations").orderBy("createdAt", Query.Direction.ASCENDING).get()
        .addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val snapshot = task.result
                val donations = snapshot.documents.map { document ->
                    val data = document.data ?: emptyMap<String, Any>()

                    // Dynamically handle the createdAt field
                    val createdAtField = document.get("createdAt")
                    val createdAt = when (createdAtField) {
                        is com.google.firebase.Timestamp -> createdAtField.toDate().toString()
                        is String -> createdAtField
                        else -> "N/A"
                    }

                    Donation(
                        donorName = "${data["firstName"] as? String ?: ""} ${data["lastName"] as? String ?: ""}".trim(),
                        email = data["email"] as? String ?: "N/A",
                        phone = data["phone"] as? String ?: "N/A",
                        campaign = data["campaignName"] as? String ?: "N/A",
                        amount = (data["amount"] as? Number)?.toString() ?: "0",
                        status = data["status"] as? String ?: "pending",
                        createdAt = createdAt
                    )
                }
                callback(donations)
            } else {
                callback(emptyList()) // Return empty list on failure
            }
        }
}

package com.example.assignment.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.assignment.AuthUtils.auth
import com.example.assignment.AuthUtils.firestore
import com.example.assignment.R
import com.example.assignment.components.ButtonComponent
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.components.MyTextFieldComponent
import com.example.assignment.components.NormalTextComponent
import com.example.assignment.components.PasswordTextFieldComponent
import com.example.assignment.ui.theme.AssignmentTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import org.mindrot.jbcrypt.BCrypt
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun CreateAdminScreen(
    onButtonClicked: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var dateOfBirth by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val context = LocalContext.current
    val auth: FirebaseAuth = auth
    val firestore: FirebaseFirestore = firestore
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        NormalTextComponent(stringResource(R.string.hey_there))
        HeadingTextComponent(stringResource(R.string.create_an_account))

        Spacer(Modifier.height(30.dp))

        MyTextFieldComponent(stringResource(R.string.email), painterResource(id = R.drawable.email), value = email, onValueChange = {email = it})
        MyTextFieldComponent(labelValue = stringResource(R.string.first_name), painterResource(id = R.drawable.person), value = firstName, onValueChange = {firstName = it})
        MyTextFieldComponent(labelValue = stringResource(R.string.last_name), painterResource(id = R.drawable.person), value = lastName, onValueChange = {lastName = it})
        MyTextFieldComponent(labelValue = stringResource(R.string.phone_number), painterResource(id = R.drawable.phone), value = phoneNumber, onValueChange = {phoneNumber = it})
        MyTextFieldComponent(labelValue = stringResource(R.string.date_of_birth), painterResource(id = R.drawable.calendar), value = dateOfBirth, onValueChange = {dateOfBirth = it})
        MyTextFieldComponent(labelValue = stringResource(R.string.gender), painterResource(id = R.drawable.gender), value = gender, onValueChange = {gender = it})
        PasswordTextFieldComponent(stringResource(R.string.password), painterResource(id = R.drawable.password), value = password, onValueChange = {password = it})
        PasswordTextFieldComponent(stringResource(R.string.confirm_password), painterResource(id = R.drawable.password), value = confirmPassword, onValueChange = {confirmPassword = it})

        Spacer(Modifier.height(34.dp))

        ButtonComponent(stringResource(R.string.register)) {
            registerUser(firstName, lastName, email, phoneNumber, password, confirmPassword, context, auth, firestore) {
                onButtonClicked()
            }
        }
    }
}

private fun registerUser(firstName: String, lastName: String, email: String, phone: String, password: String, confirmPassword: String, context: Context, auth: FirebaseAuth, firestore: FirebaseFirestore, onSuccess:() -> Unit) {

    // Simple validation check
    if (email.isEmpty() || password.isEmpty() || firstName.isEmpty() ||
        lastName.isEmpty() || phone.isEmpty()) {
        Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
        return
    }

    if (password != confirmPassword) {
        Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
        return
    }

    // Hash the password with bcrypt (using 10 as the cost factor)
    val hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt(10))  // This will use $2y$10 in the hash

    // Firebase Authentication: Register the user with the hashed password
    auth.createUserWithEmailAndPassword(email, password)
        .addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // Get current user UID
                val currentUser = auth.currentUser

                // Create user data object with the hashed password
                val userData = hashMapOf(
                    "firstName" to firstName,
                    "lastName" to lastName,
                    "user" to email,
                    "phone" to phone,
                    "role" to "admin",  // Set role to admin
                    "password" to hashedPassword, // Store hashed password
                    "createdAt" to LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/mm/yyyy, h:mm:ss A"))
                )

                // Save user data to Firestore under 'users' collection
                firestore.collection("users").document(currentUser?.uid ?: "")
                    .set(userData)
                    .addOnSuccessListener {
                        Toast.makeText(context, "Registration Successful!", Toast.LENGTH_SHORT)
                            .show()
                        onSuccess()
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(context, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
            }
        }
}
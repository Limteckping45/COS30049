package com.example.assignment.screens

import android.net.Uri
import android.text.TextUtils
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.ui.theme.AssignmentTheme


@Composable
fun SocialMediaScreen(innerPadding: PaddingValues) {
    Column(
        modifier = Modifier
            .padding(innerPadding)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
        ) {
        HeadingTextComponent("Connect and Share")
        Text(
            text = "Post your wildlife sightings and updates on social media to raise awareness",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Follow Us On Social Media",
            textAlign = TextAlign.Center,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    shouldOverrideUrlLoading(this, "https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FSemenggoh%2F&tabs=timeline&width=800&height=400&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true")
                }

            },
            modifier = Modifier
                .width(400.dp)
                .height(500.dp)
        )
        Spacer(Modifier.height(16.dp))
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    loadUrl("https://www.instagram.com/semenggohwildlifecentre/embed")
                }
            },
            modifier = Modifier
                .width(400.dp)
                .height(500.dp)
        )
        Spacer(Modifier.height(16.dp))
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun SocialMediaScreenPreview() {
    AssignmentTheme {
/*        SocialMediaScreen()*/
    }
}

private fun shouldOverrideUrlLoading(view: WebView, url: String?): Boolean {
    val host = Uri.parse(url).host
    if (url == null) {
        return true
    }
    if (!TextUtils.isEmpty(host) && url.startsWith("fb://") && host!!.contains("profile")) {
        return true
    } else {
        view.loadUrl(url)
    }
    return true
}
package com.example.assignment.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.components.NormalTextComponent
import com.example.assignment.ui.theme.AssignmentTheme

@Composable
fun AlertsScreen(innerPadding: PaddingValues) {
    var email by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .padding(innerPadding)
            .verticalScroll(rememberScrollState()),
    ) {
        HeadingTextComponent("Stay updated")
        Spacer(Modifier.height(24.dp))
        NormalTextComponent("Receive alerts on recent wildlife sightings and other important updates")

        OutlinedCard(
            border = BorderStroke(1.dp, Color.Black),
            modifier = Modifier
                .padding(8.dp)
        ) {
            Text(
                text = "Urgent Alerts",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier
                    .padding(8.dp)
            )
            Text(
                text = "• Increased poaching activity reported in Northern Reserve areas.",
                modifier = Modifier
                    .padding(horizontal = 8.dp)
            )
            Text(
                text = "• Flood warnings in the Southern region affecting animal habitats.",
                modifier = Modifier
                    .padding(8.dp)
            )
        }

        OutlinedCard(
            border = BorderStroke(1.dp, Color.Black),
            modifier = Modifier
                .padding(8.dp)
        ) {
            Text(
                text = "Recent Sightings",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier
                    .padding(8.dp)
            )
            Text(
                text = "• Endangered hornbill sighted near the river bank on October 10.",
                modifier = Modifier
                    .padding(horizontal = 8.dp)
            )
            Text(
                text = "• A family of orangutans spotted near the Semenggoh visitor center on October 9.",
                modifier = Modifier
                    .padding(8.dp)
            )
        }

        OutlinedCard(
            border = BorderStroke(1.dp, Color.Black),
            modifier = Modifier
                .padding(8.dp)
        ) {
            Text(
                text = "General Updates",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier
                    .padding(8.dp)
            )
            Text(
                text = "• New conservation efforts underway to protect freshwater ecosystems.",
                modifier = Modifier
                    .padding(horizontal = 8.dp)
            )
            Text(
                text = "• Volunteer training scheduled for next month - sign up to participate.",
                modifier = Modifier
                    .padding(8.dp)
            )
        }

        OutlinedCard(
            border = BorderStroke(1.dp, Color.Black),
            modifier = Modifier
                .padding(8.dp)
        ) {
            Text(
                text = "Subscribe to Alerts",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier
                    .padding(8.dp)
            )
            Text(
                text = "Enter your email to receive updates directly in your inbox:",
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(horizontal = 8.dp)
            )
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(16.dp)
            ) {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier
                        .width(230.dp)
                        .padding(horizontal = 8.dp)
                )
                Button(onClick = {}) {
                    Text("Subscribe")
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun AlertsScreenPreview() {
    AssignmentTheme {
        AlertsScreen(innerPadding = PaddingValues())
    }
}
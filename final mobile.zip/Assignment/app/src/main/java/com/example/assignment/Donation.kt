package com.example.assignment

data class Donation(
    val donorName: String,
    val email: String,
    val phone: String,
    val campaign: String,
    val amount: String,
    val status: String,
    val createdAt: String
)

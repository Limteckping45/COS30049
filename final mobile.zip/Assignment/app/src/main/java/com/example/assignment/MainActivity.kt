package com.example.assignment

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.assignment.screens.AdminDashboardScreen
import com.example.assignment.screens.AlertsScreen
import com.example.assignment.screens.CreateAdminScreen
import com.example.assignment.screens.DonationManagementScreen
import com.example.assignment.screens.HomeScreen
import com.example.assignment.screens.InitialScreen
import com.example.assignment.screens.LoginScreen
import com.example.assignment.screens.PaymentScreen
import com.example.assignment.screens.SettingsScreen
import com.example.assignment.screens.SightingScreen
import com.example.assignment.screens.SignUpScreen
import com.example.assignment.screens.SocialMediaScreen
import com.example.assignment.screens.TouristInfoScreen
import com.example.assignment.screens.WildlifeDataManagementScreen
import com.example.assignment.screens.WildlifeMonitoringScreen
import com.example.assignment.ui.theme.AssignmentTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.auth.User
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AssignmentTheme {
                // A surface container using the 'background' color from the theme
                NatureApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBar(
    modifier: Modifier = Modifier,
    topBarState: MutableState<Boolean>,
    navController: NavController,
    onOpenDrawer: () -> Unit
) {
    AnimatedVisibility(
        visible = topBarState.value
    ) {
        CenterAlignedTopAppBar(
            title = { Text("Hello, User")},
            navigationIcon = {
                IconButton(onClick = onOpenDrawer) {
                    Icon(painter = painterResource(id = R.drawable.menu), contentDescription = null)
                }
            },
            actions = {
                IconButton(onClick = { navController.navigate(Settings) }) {
                    Icon(painter = painterResource(id = R.drawable.user_pic), contentDescription = null)
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminTopAppBar(
    modifier: Modifier = Modifier,
    onOpenDrawer: () -> Unit
) {
    CenterAlignedTopAppBar(
        title = { Text("Admin Dashboard") },
        actions = {
            IconButton(onClick = onOpenDrawer) {
                Icon(painter = painterResource(id = R.drawable.menu), contentDescription = "Logout")
            }
        }
    )
}

@Composable
fun BottomNavBar(navController: NavController, items: List<BottomNavigationBarItems<out Any>>, bottomBarState: MutableState<Boolean>) {
    AnimatedVisibility(
        visible = bottomBarState.value
    ) {
        NavigationBar(
            modifier = Modifier
        ) {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route

            items.forEach {screen ->
                NavigationBarItem(
                    selected = currentRoute == screen.route,
                    onClick = {
                        if (currentRoute != screen.route) {
                            navController.navigate(screen.route)
                        }
                    },
                    icon = { Icon(painter = painterResource(screen.icon), contentDescription = null) },
                    label = { Text(text = screen.label) }
                )
            }
        }
    }
}

@Composable
fun NatureApp() {
    val navController = rememberNavController()
    val topBarState = rememberSaveable{ mutableStateOf(false) }
    val bottomBarState = rememberSaveable{ mutableStateOf(false) }
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val drawerState = rememberDrawerState(
        initialValue = DrawerValue.Closed
    )
    val scope = rememberCoroutineScope()
    val adminScope = rememberCoroutineScope()
    val role = rememberSaveable { mutableStateOf("") }

    navBackStackEntry?.destination?.let { currentDestination ->
        if (currentDestination.hasRoute(Home::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else if (currentDestination.hasRoute(Settings::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else if (currentDestination.hasRoute(TouristInfo::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else if (currentDestination.hasRoute(Payment::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else if (currentDestination.hasRoute(Sighting::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else if (currentDestination.hasRoute(Social::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else if (currentDestination.hasRoute(WildlifeMonitoring::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else if (currentDestination.hasRoute(Alerts::class)) {
            topBarState.value = true
            bottomBarState.value = true
        } else {
            topBarState.value = false
            bottomBarState.value = false
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.fillMaxWidth(0.7f)) {
                if (role.value == "admin") {
                    AdminDrawerContent(navController = navController)
                } else if (role.value == "user") {
                    UserDrawerContent(navController = navController)
                }
            }
        },
        gesturesEnabled = true
    ) {
        Scaffold (
            topBar = {
                if (role.value == "admin") {
                    AdminTopAppBar {
                        scope.launch {
                            drawerState.apply {
                                if (isClosed) open() else close()
                            }
                        }
                    }
                } else if (role.value == "user" ) {
                    TopAppBar(modifier = Modifier, topBarState, navController) {
                        scope.launch {
                            drawerState.apply {
                                if (isClosed) open() else close()
                            }
                        }
                    }
                }
            },
            content = { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = Initial
                ) {
                    composable<Initial> {
                        InitialScreen(modifier = Modifier, navController)
                    }
                    composable<Login> {
                        LoginScreen(
                            onAdminLogin = {
                                role.value = "admin"
                                navController.navigate(AdminDashboard)
                            },
                            onUserLogin = {
                                role.value = "user"
                                navController.navigate(Home)
                            }
                        )
                    }
                    composable<SignUp> {
                        SignUpScreen(
                            onButtonClicked = {
                                navController.navigate(Home)
                            }
                        )
                    }
                    composable<Home> {
                        HomeScreen(innerPadding = innerPadding, navController = navController)
                    }
                    composable<Settings> {
                        SettingsScreen(innerPadding) {
                            role.value = ""
                            navController.navigate(Initial)
                        }
                    }
                    composable<Payment> {
                        PaymentScreen(innerPadding = innerPadding)
                    }
                    composable<TouristInfo> {
                        TouristInfoScreen(innerPadding)
                    }
                    composable<Sighting> {
                        SightingScreen(innerPadding)
                    }
                    composable<AdminDashboard> {
                        AdminDashboardScreen(innerPadding)
                    }
                    composable<Social> {
                        SocialMediaScreen(innerPadding)
                    }
                    composable<WildlifeMonitoring> {
                        WildlifeMonitoringScreen(innerPadding)
                    }
                    composable<Alerts> {
                        AlertsScreen(innerPadding)
                    }
                    composable<WildlifeDataManagement> {
                        WildlifeDataManagementScreen(innerPadding)
                    }
                    composable<DonationManagement> {
                        DonationManagementScreen(innerPadding)
                    }
                    composable<CreateAdmin> {
                        CreateAdminScreen() {
                            navController.navigate(AdminDashboard)
                        }
                    }
                }
            },
            bottomBar = {
                BottomNavBar(navController, bottomNavItems, bottomBarState)
            }
        )
    }
}

@Composable
fun UserDrawerContent(modifier: Modifier = Modifier, navController: NavController) {
    Text(
        text = "Semenggoh Nature Reserve",
        fontSize = 24.sp,
        modifier = Modifier.padding(16.dp)
    )

    HorizontalDivider()

    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.home), contentDescription = null)
        },
        label = {
            Text(
                text = "Home",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Home)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.search), contentDescription = null)
        },
        label = {
            Text(
                text = "Search",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(TouristInfo)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.settings), contentDescription = null)
        },
        label = {
            Text(
                text = "Settings",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Settings)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.donation), contentDescription = null)
        },
        label = {
            Text(
                text = "Donation",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Payment)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.map), contentDescription = null)
        },
        label = {
            Text(
                text = "Wildlife Monitoring",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(WildlifeMonitoring)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.cloud_upload), contentDescription = null)
        },
        label = {
            Text(
                text = "Sighting Map",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Sighting)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.alert), contentDescription = null)
        },
        label = {
            Text(
                text = "Alerts",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Alerts)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.social), contentDescription = null)
        },
        label = {
            Text(
                text = "Social Media",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Social)}
    )
}

@Composable
fun AdminDrawerContent(modifier: Modifier = Modifier, navController: NavController) {
    Text(
        text = "Semenggoh Nature Reserve",
        fontSize = 24.sp,
        modifier = Modifier.padding(16.dp)
    )

    HorizontalDivider()

    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.home), contentDescription = null)
        },
        label = {
            Text(
                text = "Home",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Home)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.search), contentDescription = null)
        },
        label = {
            Text(
                text = "Search",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(TouristInfo)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.settings), contentDescription = null)
        },
        label = {
            Text(
                text = "Settings",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Settings)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.donation), contentDescription = null)
        },
        label = {
            Text(
                text = "Donation",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Payment)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.map), contentDescription = null)
        },
        label = {
            Text(
                text = "Wildlife Monitoring",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(WildlifeMonitoring)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.cloud_upload), contentDescription = null)
        },
        label = {
            Text(
                text = "Sighting Map",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Sighting)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.alert), contentDescription = null)
        },
        label = {
            Text(
                text = "Alerts",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Alerts)}
    )
    NavigationDrawerItem(
        icon = {
            Image(painter = painterResource(id = R.drawable.social), contentDescription = null)
        },
        label = {
            Text(
                text = "Social Media",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(Social)}
    )
    NavigationDrawerItem(
        label = {
            Text(
                text = "Admin Dashboard",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(AdminDashboard)}
    )
    NavigationDrawerItem(
        label = {
            Text(
                text = "Wildlife Data Management",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(WildlifeDataManagement)}
    )
    NavigationDrawerItem(
        label = {
            Text(
                text = "Donation Management",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(DonationManagement)}
    )
    NavigationDrawerItem(
        label = {
            Text(
                text = "Create Admin",
                fontSize = 17.sp,
                modifier = Modifier.padding(16.dp)
            )
        },
        selected = false,
        onClick = {navController.navigate(CreateAdmin)}
    )
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun GreetingPreview() {
    AssignmentTheme {
        NatureApp()
    }
}
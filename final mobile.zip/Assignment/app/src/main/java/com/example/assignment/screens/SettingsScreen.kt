package com.example.assignment.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.assignment.R
import com.example.assignment.components.NormalTextComponent
import com.example.assignment.ui.theme.AssignmentTheme

@Composable
fun SettingsScreen(innerPadding: PaddingValues, onLogOut: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(innerPadding)
    ) {
        Spacer(Modifier.height(50.dp))
        Image(painter = painterResource(id = R.drawable.user_pic), contentDescription = null, modifier = Modifier.size(100.dp))
        NormalTextComponent("User")

        Spacer(Modifier.height(50.dp))
        OptionsComponent("About us", R.drawable.help) {

        }
        Divider()
        OptionsComponent("Change password", R.drawable.password) {

        }
        Divider()
        OptionsComponent("Log out", R.drawable.logout) {
            onLogOut()
        }
        Divider()
    }
}

@Composable
fun OptionsComponent(
    textValue: String,
    icon: Int,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row{
            Image(painter = painterResource(id = icon), contentDescription = null, modifier = Modifier.padding(horizontal = 8.dp))
            Text(text = textValue)
        }
        Image(painter = painterResource(id = R.drawable.right_arrow), contentDescription = null)
    }
}

@Composable
fun Divider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        thickness = 1.dp,
        color = Color.Black
    )
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun SettingsScreenPreview() {
    AssignmentTheme {
//        SettingsScreen(innerPadding = PaddingValues())
    }
}

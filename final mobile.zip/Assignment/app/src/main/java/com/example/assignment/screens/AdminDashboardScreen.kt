package com.example.assignment.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.breens.beetablescompose.BeeTablesCompose
import com.example.assignment.Account
import com.example.assignment.AuthUtils.firestore
import com.example.assignment.R
import com.example.assignment.Settings
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.ui.theme.AssignmentTheme
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.coroutines.tasks.await
import java.util.Date

@Composable
fun AdminDashboardScreen(innerPadding: PaddingValues) {
    Column(modifier = Modifier
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
    ) {
        HeadingTextComponent("Admin Dashboard")
        val tableHeaders = listOf("ID", "User", "Role", "Created At")
        var users by remember { mutableStateOf<List<Account>>(emptyList()) }

        LaunchedEffect(Unit) {
            fetchAccounts { result ->
                // Update the users state once data is fetched
                users = result
            }
        }

        BeeTablesCompose(
            data = users,
            headerTableTitles = tableHeaders,
            dividerThickness = 0.8.dp,
        )
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun AdminDashboardScreenPreview() {
    AssignmentTheme {
        AdminDashboardScreen(innerPadding = PaddingValues())
    }
}


private fun fetchAccounts(callback: (List<Account>) -> Unit) {
    val firestore = FirebaseFirestore.getInstance()

    firestore.collection("users").get()
        .addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val snapshot = task.result
                val accounts = snapshot.documents.map { document ->
                    // Inspect the type of the 'createdAt' field
                    val createdAtField = document.get("createdAt")
                    val createdAt = when (createdAtField) {
                        is com.google.firebase.Timestamp -> {
                            // Convert Timestamp to Date and format it
                            createdAtField.toDate().toString()
                        }
                        is String -> {
                            // If it is already a String
                            createdAtField
                        }
                        is Long -> {
                            // If it's a Long, assume it's a Unix timestamp
                            Date(createdAtField).toString()
                        }
                        is Date -> {
                            // If it's a Date object
                            createdAtField.toString()
                        }
                        else -> {
                            // Unknown or null field
                            "N/A"
                        }
                    }

                    Account(
                        id = document.id,
                        user = document.getString("user") ?: "N/A",
                        role = document.getString("role") ?: "N/A",
                        createdAt = createdAt
                    )
                }
                callback(accounts)
            } else {
                callback(emptyList()) // Handle error case by passing an empty list
            }
        }
}

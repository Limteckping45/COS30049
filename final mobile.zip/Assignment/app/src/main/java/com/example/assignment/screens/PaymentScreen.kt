package com.example.assignment.screens

import android.widget.Space
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withLink
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assignment.R
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.components.MyTextFieldComponent
import com.example.assignment.components.NormalTextComponent
import com.example.assignment.ui.theme.AssignmentTheme
import kotlin.math.exp
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.ktx.Firebase
import com.google.firebase.firestore.ktx.firestore

@Composable
fun PaymentScreen(innerPadding: PaddingValues) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var selectedText by remember { mutableStateOf("Wildlife Conservation") }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .padding(innerPadding)
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        HeadingTextComponent("Donation to Semenggoh Nature Reserve")

        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = firstName,
            onValueChange = { firstName = it },
            label = { Text("First name") }
        )
        OutlinedTextField(
            value = lastName,
            onValueChange = { lastName = it },
            label = { Text("Last name") }
        )
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        OutlinedTextField(
            value = phoneNumber,
            onValueChange = { phoneNumber = it },
            label = { Text("Phone number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )

        DropDownMenu(selectedText, onSelectedTextChange = { selectedText = it})

        Spacer(Modifier.height(16.dp))

        DonateButton(
            firstName = firstName,
            lastName = lastName,
            email = email,
            phoneNumber = phoneNumber,
            selectedText = selectedText
        )

        Spacer(Modifier.height(16.dp))

        Image(painter = painterResource(id = R.drawable.debit_credit_apm), contentDescription = null)

        Spacer(Modifier.height(16.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Powered by",
                fontSize = 16.sp,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Image(painter = painterResource(id = R.drawable.paypal_logo), contentDescription = null, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text(
            text = "Pay through PayPal with QR",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(8.dp))
        Image(painter = painterResource(id = R.drawable.paymentqr), contentDescription = null, modifier = Modifier.size(200.dp))
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DonateButton(
    firstName: String,
    lastName: String,
    email: String,
    phoneNumber: String,
    selectedText: String
) {
    val uriHandler = LocalUriHandler.current
    val firestore = FirebaseFirestore.getInstance()

    // Donation handler logic
    val handleDonation = {
        val donationData = hashMapOf(
            "firstName" to firstName,
            "lastName" to lastName,
            "email" to email,
            "phone" to phoneNumber,
            "campaign" to selectedText,  // Use selectedText for the campaign
            "amount" to 0, // Placeholder for donation amount
            "status" to "pending",
            "createdAt" to FieldValue.serverTimestamp(),
            "lastUpdated" to FieldValue.serverTimestamp()
        )

        // Firestore operation: Add donation
        firestore.collection("donations")
            .add(donationData)
            .addOnSuccessListener {
                Log.d("DonateButton", "Donation added successfully!")
                uriHandler.openUri("https://www.sandbox.paypal.com/ncp/payment/V92RUJ8YLDWQE") // PayPal URL
            }
            .addOnFailureListener { e ->
                Log.e("DonateButton", "Error adding donation", e)
            }
    }

    // Button to trigger donation
    Button(onClick = { handleDonation() }) {
        Text(text = "Donate", color = Color.White)
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PaymentScreenPreview() {
    AssignmentTheme {
        PaymentScreen(innerPadding = PaddingValues())
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DropDownMenu(
    selectedText: String,
    onSelectedTextChange: (String) -> Unit // Callback for updating state
) {
    val list = listOf("Wildlife Conservation", "Orangutan Conservation", "Habitat Restoration")
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ExposedDropdownMenuBox(
            expanded = isExpanded,
            onExpandedChange = { isExpanded = !isExpanded }
        ) {
            TextField(
                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                value = selectedText,
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded) }
            )

            ExposedDropdownMenu(
                expanded = isExpanded,
                onDismissRequest = { isExpanded = false }
            ) {
                list.forEach { text ->
                    DropdownMenuItem(
                        text = { Text(text = text) },
                        onClick = {
                            onSelectedTextChange(text) // Update the lifted state
                            isExpanded = false
                        },
                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                    )
                }
            }
        }
    }
}
package com.example.assignment.screens

import android.provider.ContactsContract.Contacts.Photo
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.assignment.R
import com.example.assignment.components.ButtonComponent
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.ui.theme.AssignmentTheme

@Composable
fun SightingScreen(innerPadding: PaddingValues) {
    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            Log.d("PhotoPicker", "Selected URI: $uri")
        } else {
            Log.d("PhotoPicker", "No media selected")
        }
    }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center){
        HeadingTextComponent("Map of Wildlife Sightings")
        Spacer(Modifier.height(40.dp))
        Text(
            text = "Explore recent wildlife sightings shared by other users, and add your own sightings to help track animal activity",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Box(modifier = Modifier
            .size(300.dp)
            .border(2.dp, Color.Gray, shape = RoundedCornerShape(8.dp))
            .padding(16.dp)) {
            Column(modifier = Modifier
                .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,) {
                Text(
                    text = "Uploads of Wildlife Sighting",
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(24.dp))
                Image(painter = painterResource(id = R.drawable.cloud_upload), contentDescription = null, modifier = Modifier.size(100.dp))
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                ) {
                    Text("Choose file")
                }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun SightingScreenPreview() {
    AssignmentTheme {
        SightingScreen(innerPadding = PaddingValues())
    }
}
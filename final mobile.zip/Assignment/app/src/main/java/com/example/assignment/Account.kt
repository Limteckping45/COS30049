package com.example.assignment

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import java.util.Date

data class Account(
    val id: String,
    val user: String,
    val role: String,
    val createdAt: String
)

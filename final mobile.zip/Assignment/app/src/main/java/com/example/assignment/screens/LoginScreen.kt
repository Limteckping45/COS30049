package com.example.assignment.screens

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.assignment.AuthUtils.auth
import com.example.assignment.AuthUtils.firestore
import com.example.assignment.R
import com.example.assignment.components.ButtonComponent
import com.example.assignment.components.HeadingTextComponent
import com.example.assignment.components.MyTextFieldComponent
import com.example.assignment.components.PasswordTextFieldComponent
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import org.mindrot.jbcrypt.BCrypt
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import com.google.firebase.firestore.FieldValue

@Composable
fun LoginScreen(
    modifier: Modifier = Modifier,
    onAdminLogin: () -> Unit,
    onUserLogin: () -> Unit
) {
    val auth: FirebaseAuth = auth
    val firestore: FirebaseFirestore = firestore
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context: Context = LocalContext.current

    Surface {
        Column (
            modifier = modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            HeadingTextComponent("Welcome back!")
            HeadingTextComponent("Sign in")

            Spacer(modifier = Modifier.height(80.dp))

            MyTextFieldComponent("Email", painterResource(id = R.drawable.email), value = email, onValueChange = {email = it})
            PasswordTextFieldComponent("Password", painterResource(id = R.drawable.password), value = password, onValueChange = {password = it})

            Spacer(modifier = Modifier.height(32.dp))

            ButtonComponent("Login") {
                if (email.isNotEmpty() && password.isNotEmpty()) {
                    println(email)
                    println(password)
                    loginUser(email, password, firestore, context, onAdminLogin, onUserLogin)
                }
            }
        }
    }
}

//@Preview(showBackground = true, showSystemUi = true)
//@Composable
//fun LoginScreenPreview() {
//    AssignmentTheme {
//        LoginScreen(
//            onButtonClicked = {}
//        )
//    }
//}

private fun loginUser(
    email: String,
    password: String,
    firestore: FirebaseFirestore,
    context: Context,
    onAdminLogin: () -> Unit,
    onUserLogin: () -> Unit
) {
    val usersRef = firestore.collection("users")

    usersRef
        .whereEqualTo("user", email) // Find the user by email
        .get()
        .addOnSuccessListener { querySnapshot ->
            if (querySnapshot.isEmpty) {
                Toast.makeText(context, "User not found", Toast.LENGTH_SHORT).show()
            } else {
                val userDoc = querySnapshot.documents[0]
                val userData = userDoc.data

                if (userData != null) {
                    val storedPassword = userData["password"] as String
                    val role = userData["role"] as String
                    val firstName = userData["firstName"] as String
                    val lastName = userData["lastName"] as String
                    val phoneno: Long = (userData["phoneno"] as? Long) ?: 0
                    val currentDate = FieldValue.serverTimestamp()
                    val email = userData["user"] as String
                    val adjustedStoredPassword = storedPassword.replaceFirst("$2y$", "$2a$")
                    // Verify password using bcrypt
                    if (BCrypt.checkpw(password, adjustedStoredPassword)) {
                        println(currentDate.toString())
                        saveUserData(context, firstName, lastName, phoneno, role, email, currentDate)
//                         Navigate based on user role
                        when (role) {
                            "admin" -> onAdminLogin()
                            "user" -> onUserLogin()
                            else -> Toast.makeText(context, "Unknown role", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(context, "Incorrect password", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        .addOnFailureListener { exception ->
            Toast.makeText(context, "Error fetching user data: ${exception.message}", Toast.LENGTH_SHORT).show()
        }
}

private fun saveUserData(
    context: Context,
    firstName: String,
    lastName: String,
    phoneno: Long,
    role: String,
    email: String,
    currentDate: FieldValue
) {
    val sharedPref = context.getSharedPreferences("userData", Context.MODE_PRIVATE)
    val editor = sharedPref.edit()
    editor.putString("firstName", firstName)
    editor.putString("lastName", lastName)
    editor.putLong("phoneno", phoneno)
    editor.putString("role", role)
    editor.putString("email", email)
    editor.putString("createdAt", currentDate.toString()) // Store timestamp as string
    println(currentDate.toString())
    editor.apply()
}
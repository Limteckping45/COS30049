package com.example.assignment

import kotlinx.serialization.Serializable

@Serializable object Home
@Serializable object Settings
@Serializable object Initial
@Serializable object SignUp
@Serializable object Login
@Serializable object TouristInfo
@Serializable object Payment
@Serializable object Sighting
@Serializable object AdminDashboard
@Serializable object Social
@Serializable object WildlifeMonitoring
@Serializable object Alerts
@Serializable object WildlifeDataManagement
@Serializable object DonationManagement
@Serializable object CreateAdmin

data class BottomNavigationBarItems<T: Any>(val route: T, val label: String, val icon: Int)

val bottomNavItems = listOf(
    BottomNavigationBarItems(route = Home, label = "Home", icon = R.drawable.home),
    BottomNavigationBarItems(route = TouristInfo, label = "Search", icon = R.drawable.search),
    BottomNavigationBarItems(route = Settings, label = "Settings", icon = R.drawable.settings),
    BottomNavigationBarItems(route = Payment, label = "Donation", icon = R.drawable.donation)
)
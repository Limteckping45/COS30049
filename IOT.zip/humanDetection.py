import firebase_admin
from firebase_admin import credentials, firestore
import torch
import numpy as np
import cv2
import base64
import os
from time import time

# Firebase setup
service_account_key_path = 'serviceKey.json'
cred = credentials.Certificate(service_account_key_path)
firebase_admin.initialize_app(cred)
db = firestore.client()

# Folder to save output images
output_folder = "output_picture"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Function to fetch images from Firestore where status is null
def fetch_images_from_firestore():
    try:
        collection_ref = db.collection('IoT')
        query = collection_ref.where('status', '==', None)
        docs = query.stream()
        images = [(doc.id, doc.to_dict()['image']) for doc in docs]
        return images
    except Exception as e:
        print(f"Error fetching images from Firestore: {e}")
        return []

# Main function
def main():
    try:
        # Fetch images with null status
        images = fetch_images_from_firestore()
        if not images:
            print("No images found with null status.")
            return

        # Device selection
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(f"Using device: {device}")

        # Load the YOLOv7-tiny model for faster detection
        model = torch.hub.load('WongKinYiu/yolov7', 'yolov7', pretrained=True, trust_repo=True)
        model.to(device).eval()
        if device != 'cpu':  # Use FP16 if GPU is available
            model.half()

        # Set YOLOv7 model confidence and IOU thresholds
        model.conf = 0.25  # Confidence threshold
        model.iou = 0.45   # IOU threshold for NMS

        # Process each image
        for img_id, img_data in images:
            try:
                start_time = time()
                print(f"Processing image ID: {img_id}")

                # Decode the Base64 string to an image
                img_binary = base64.b64decode(img_data)
                nparr = np.frombuffer(img_binary, np.uint8)
                img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

                # Resize image for faster processing
                img = cv2.resize(img, (640, 640))

                # Perform detection
                with torch.inference_mode():
                    results = model([img])

                # Render results on the image
                results.render()
                result_image = results.imgs[0]

                # Save the processed image
                output_image_path = os.path.join(output_folder, f"output_{img_id}.jpg")
                cv2.imwrite(output_image_path, result_image)
                print(f"Processed image saved to: {output_image_path}")

                # Determine if a human was detected
                human_detected = any(det[5] == 0 for det in results.pred[0])  # 0 = person class
                status = "human detected" if human_detected else "human not detected"

                # Update the image status in Firestore
                db.collection('IoT').document(img_id).update({'status': status})
                print(f"Image ID {img_id} status updated to: {status}")
                print(f"Processing time: {time() - start_time:.2f}s")

            except Exception as e:
                print(f"Error processing image ID {img_id}: {e}")

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()

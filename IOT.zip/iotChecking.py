import requests
import time
import argparse
from bs4 import BeautifulSoup
import subprocess  # To run another Python script
import sys
import os
import cv2  # OpenCV for camera control

# Function to fetch the latest sensor data from the ESP32 web server
def fetch_data(esp32_ip, last_fetched_data):
    try:
        # Send a GET request to the root endpoint of the ESP32 server
        response = requests.get(f"http://{esp32_ip}")

        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            html_content = response.text

            # Use BeautifulSoup to parse the HTML and extract the table rows
            soup = BeautifulSoup(html_content, 'html.parser')
            table = soup.find('table')

            # If there's a table, process the rows
            if table:
                rows = table.find_all('tr')[1:]  # Exclude the header row

                # Loop through each row and check for new data
                new_data_found = False
                for row in rows:
                    columns = row.find_all('td')
                    if columns and len(columns) > 1:
                        # sensor = columns[0].text.strip()
                        output = columns[1].text.strip()

                        # Check if this output is not already in last fetched data
                        if output not in last_fetched_data:
                            last_fetched_data.append(output)  # Update the tracked data
                            new_data_found = True

                return new_data_found, last_fetched_data  # Return True if new data found
            else:
                print("No table found in the HTML content.")
                return False, last_fetched_data

        else:
            print(f"Failed to fetch data from ESP32. HTTP Status Code: {response.status_code}")
            return False, last_fetched_data

    except Exception as e:
        print(f"Error fetching data: {e}")
        return False, last_fetched_data

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Fetch new data from the ESP32 server.')
    parser.add_argument('esp32_ip', type=str, help='The IP address of the ESP32 device')
    args = parser.parse_args()

    # To track the output data and avoid printing duplicates
    last_fetched_data = []

    # Initialize the webcam
    camera = cv2.VideoCapture(0)
    if not camera.isOpened():
        print("Error: Could not open the camera.")
        return
    print("Camera activated.")

    try:
        while True:
            # Fetch the latest sensor data and check if there is new data
            new_data_found, last_fetched_data = fetch_data(args.esp32_ip, last_fetched_data)
            
            # If new data is found, run "firebaseInsertData.py"
            if new_data_found:
                # Path to the Python scripts
                firebase_script_path = os.path.join(os.getcwd(), "firebaseInsertData.py")  # Absolute path to firebaseInsertData.py
                human_detection_script_path = os.path.join(os.getcwd(), "humanDetection.py")  # Absolute path to humanDetection.py

                print(f"Running {firebase_script_path}...")  # Print to verify the script path
                subprocess.run([sys.executable, firebase_script_path], capture_output=True, text=True)

                print(f"Running {human_detection_script_path}...")  # Print to verify the script path
                subprocess.run([sys.executable, human_detection_script_path], capture_output=True, text=True)
            else:
                # If no new data, print a message and wait for the next update
                print("No new data found. Waiting for next update.")
            
            # Wait for 2 seconds before checking again
            time.sleep(2)

    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        print("\nProgram interrupted. Exiting...")
    finally:
        # Ensure the camera is released on shutdown
        camera.release()
        cv2.destroyAllWindows()
        print("Camera deactivated.")

if __name__ == "__main__":
    main()

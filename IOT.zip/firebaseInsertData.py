import cv2
import time
import os
import random
import string
import threading
import base64
from datetime import datetime
import requests
import firebase_admin
from firebase_admin import credentials, firestore
from queue import Queue

# Initialize Firebase Admin SDK
service_account_key_path = 'serviceKey.json'  # Replace with your actual path to serviceAccountKey.json
cred = credentials.Certificate(service_account_key_path)
firebase_admin.initialize_app(cred)

# Firestore client
db = firestore.client()

# Define the directory to save pictures and metadata
save_directory = r"C:\Users\teckp\OneDrive\Desktop\COS30049\Assignment\yolov7\Picture"
os.makedirs(save_directory, exist_ok=True)

# Initialize the webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Function to generate a unique ID (yyyyMMdd-random8)
def generate_unique_id():
    date_str = datetime.now().strftime("%Y%m%d")
    random_str = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    return f"{date_str}-{random_str}"

# Function to check internet connection
def is_connected():
    try:
        requests.get("https://www.google.com", timeout=5)
        return True
    except requests.ConnectionError:
        return False

# Function to upload the image to Firestore
def upload_image_to_firestore(image_path, unique_id, date_time, status=None, coordinate="Zone A"):
    try:
        # Read and encode the image to base64
        with open(image_path, "rb") as file:
            image_base64 = base64.b64encode(file.read()).decode('utf-8')

        # Firestore document reference
        collection_ref = db.collection('IoT')
        doc_ref = collection_ref.document(unique_id)

        # Data to store in Firestore
        data = {
            'id': unique_id,
            'image': image_base64,
            'dateTime': date_time,
            'status': status,
            'coordinate': coordinate
        }

        # Set the document with data
        doc_ref.set(data)
        print(f"Successfully uploaded {image_path} to Firestore.")
        return True

    except Exception as e:
        print(f"Error uploading image {image_path}: {e}")
        return False

# Worker function for asynchronous uploads
def upload_worker(queue):
    while True:
        task = queue.get()
        if task is None:
            break  # Stop the worker
        success = upload_image_to_firestore(*task)
        if not success:
            # Save the task for retrying later
            image_path, unique_id, date_time, status, coordinate = task
            with open(f"{image_path}.meta", "w") as meta_file:
                meta_file.write(f"{unique_id},{date_time},{status},{coordinate}")
        queue.task_done()

# Initialize the upload queue and worker thread
upload_queue = Queue()
thread = threading.Thread(target=upload_worker, args=(upload_queue,))
thread.start()

# Give the camera a moment to warm up
time.sleep(1)

# Take 5 pictures
for i in range(3):
    ret, frame = cap.read()
    if ret:
        # Save the frame as a JPEG file in the specified directory
        image_name = f"picture_{i + 1}.jpg"
        image_path = os.path.join(save_directory, image_name)
        cv2.imwrite(image_path, frame)
        print(f"Captured {image_name}")

        # Generate a unique ID for this image
        unique_id = generate_unique_id()
        date_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Check connectivity and either upload or save for later
        if is_connected():
            upload_queue.put((image_path, unique_id, date_time, None, None))
        else:
            print("No internet connection. Saving image for later upload.")
            # Save metadata for retrying
            with open(f"{image_path}.meta", "w") as meta_file:
                meta_file.write(f"{unique_id},{date_time},None,None")

        # Wait 1 second between captures
        time.sleep(1)

    else:
        print("Error: Could not read from webcam.")

# Wait for all uploads to complete
upload_queue.join()

# Stop the worker thread
upload_queue.put(None)
thread.join()

# Release the webcam
cap.release()
cv2.destroyAllWindows()

import os
import cv2
import pytesseract
import re
import pandas as pd

# Function to extract date, time, and temperature using OCR
def extract_metadata(image_path):
    image = cv2.imread(image_path)
    # Crop the area containing date, time, temperature (adjust coordinates as needed)
    text_region = image[0:50, 0:image.shape[1]]  # Adjust if needed for the specific text area
    gray = cv2.cvtColor(text_region, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    
    # OCR to get text
    text = pytesseract.image_to_string(thresh)
    
    # Use regex to extract Date, Time, Temperature
    date_match = re.search(r"\d{4}-\d{2}-\d{2}", text)
    time_match = re.search(r"\d{2}:\d{2}:\d{2}", text)
    temperature_match = re.search(r"\d{2}°C", text)
    
    date = date_match.group(0) if date_match else "Not found"
    time = time_match.group(0) if time_match else "Not found"
    temperature = temperature_match.group(0) if temperature_match else "Not found"
    
    return date, time, temperature

# Function to recursively process all images in the directory structure
def process_directory(root_dir):
    data = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Get the immediate parent folder name (Area folder, e.g., 0002-A, 0002-B)
        area_folder = os.path.basename(os.path.dirname(dirpath))
        
        # Add a row for the first subdirectory (e.g., "Filter") with correct zone information
        if dirpath.endswith("Filter"):
            zone = area_folder  # Use the Area folder name as Zone
            data.append({
                "Zone": zone,  # Correct zone information based on area folder
                "Area": "Filter",  # Always "Filter" for this row
                "Species Name": "Not found",  # Placeholder, will be filled later
                "Date": "Not found",  # Placeholder
                "Time": "Not found",  # Placeholder
                "Temperature": "Not found",  # Placeholder
                "Image Number": "Not found"  # Placeholder
            })
            print(f"Added Filter directory row for area {area_folder}")
        
        # Process images in the current directory (species name folder)
        for filename in filenames:
            if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                img_path = os.path.join(dirpath, filename)
                species_name = os.path.basename(dirpath)  # Use current folder as species name
                # Extract date, time, temperature
                date, time, temperature = extract_metadata(img_path)
                # Extract image number
                img_number = os.path.splitext(filename)[0]
                # Append data with correct zone and area name
                data.append({
                    "Zone": area_folder,  # Add zone information based on area folder
                    "Area": "Filter",  # Always "Filter" for this row
                    "Species Name": species_name,
                    "Date": date,
                    "Time": time,
                    "Temperature": temperature,
                    "Image Number": img_number
                })
                # Print progress for each image
                print(f"Processed image: {filename} in species {species_name} under area {area_folder}")

    # Convert the collected data to a DataFrame
    df = pd.DataFrame(data)
    return df

# Set the root directory and process
root_directory = r"D:\Swinburne\Degree2_S2\COS30049_Computing_Technology_innovation_Project\COS30049_cameraTrapHabitatData\COS30049_camera_trap_images"
df = process_directory(root_directory)

# Save the DataFrame to an Excel file
df.to_excel("dataset.xlsx", index=False)
print("Dataset saved as dataset.xlsx")
